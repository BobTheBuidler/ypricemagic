Use this tool to extract historical on-chain price data from an archive node. 

Shoutout to [Banteg] (https://github.com/banteg) [(@bantg)] (https://twitter.com/bantg) and [nymmrx] (https://github.com/nymmrx) [(@nymmrx)] (https://twitter.com/nymmrx) for their awesome work on [yearn-exporter] (https://github.com/yearn/yearn-exporter) that made this library possible.

