from joblib import Memory

memory = Memory("cache", verbose=0)
